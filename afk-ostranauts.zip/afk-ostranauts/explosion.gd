extends Node2D

func  _ready() -> void:
	scale = Vector2(0.2, 0.2)
	
	var tween = create_tween()
	
	tween.tween_property(self, "scale", Vector2(1, 1), 0.3)
	
	tween.tween_property(self, "modulate:a", 0.0, 0.2)
	
	await tween.finished
	queue_free()
