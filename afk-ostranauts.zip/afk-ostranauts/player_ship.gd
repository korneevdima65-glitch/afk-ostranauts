extends CharacterBody2D

@onready var hp_bar = $ProgressBar
@onready var laser_scene = preload("res://Laser.tscn")

var hp = 100
var damage = 10
var target = null


func _ready():
	
	hp_bar.max_value = hp
	hp_bar.value = hp

	await get_tree().process_frame

	var enemies = get_tree().get_nodes_in_group("enemy")

	if enemies.size() > 0:

		target = enemies[0]
		
func take_damage(amount):

	hp -= amount

	hp_bar.value = hp

	print("PLAYER HP:", hp)

	if hp <= 0:

		queue_free()

func _on_attack_timer_timeout() -> void:

	if target != null:

		target.take_damage(damage)



func _on_skill_timer_timeout() -> void:

	if target == null:
		return

	var laser = laser_scene.instantiate()

	get_parent().add_child(laser)

	laser.global_position = global_position

	laser.target = target
