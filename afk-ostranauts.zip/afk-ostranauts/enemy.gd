extends CharacterBody2D

var hp = 100
var damage = 5
var target = null


@onready var hp_bar = $ProgressBar
@onready var explosion_scene = preload("res://Explosion.tscn")

func _ready():
	
	hp_bar.max_value = hp
	hp_bar.value = hp
	
	await get_tree().process_frame

	var players = get_tree().get_nodes_in_group("player")

	if players.size() > 0:

		target = players[0]

func  take_damage(amount):
	
	hp -= amount
	
	print("HP осталось", hp)
	
	hp_bar.value = hp
	$Sprite2D.modulate = Color(1, 0, 0)

	await get_tree().create_timer(0.1).timeout

	$Sprite2D.modulate = Color(1, 1, 1)

	if hp <= 0:
		
		var explosion = explosion_scene.instantiate()

		get_parent().add_child(explosion)

		explosion.global_position = global_position
		
		queue_free()


func _on_regen_timer_timeout() -> void:
	
	hp += 1

	if hp > hp_bar.max_value:
		hp = hp_bar.max_value

	hp_bar.value = hp

	#print("Реген HP:", hp)


func _on_attack_timer_timeout() -> void:

	if target != null:

		target.take_damage(damage)
