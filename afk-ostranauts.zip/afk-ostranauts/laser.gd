extends Area2D

var speed = 150
var hit = false
var target = null


func _process(delta):

	if target != null:
		

		var direction = global_position.direction_to(target.global_position)

		global_position += direction * speed * delta
	
func _on_body_entered(body):

	if hit:
		return

	if body.has_method("take_damage"):

		hit = true

		print("DAMAGE")

		body.take_damage(10)

		queue_free()
